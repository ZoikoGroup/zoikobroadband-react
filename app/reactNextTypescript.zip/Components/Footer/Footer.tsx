import Link from "next/link";
import FooterMenu from "./FooterMenu";

export default function Footer() {

  const footerSections = [
    {
      id: "broadband",
      title: "Zoiko Broadband",
      links: [
        { name: "Broadband Plans", href: "/fibre-packages" },
        { name: "Business Broadband", href: "/business-broadband" },
        { name: "Digital Lines Options", href: "/digital-lines" },
        { name: "Bundles & Save", href: "/bundles" },
        { name: "Check my postcode", href: "/check-my-postcode" },
        { name: "Refer a friend", href: "/refer-a-friend" },
      ],
    },
    {
      id: "support",
      title: "Support",
      links: [
        { name: "Get Help", href: "/get-help" },
        { name: "Setup & Installation", href: "/setup-installation" },
        { name: "Manage My Account", href: "/dashboard" },
        { name: "Payments & Billing", href: "/payments-billing" },
        { name: "Report a Fault", href: "/report-a-fault" },
        { name: "Contact Us", href: "/contact-us" }
      ],
    },
    {
      id: "legal",
      title: "Legal",
      links: [
        { name: "Terms & Conditions", href: "/terms-conditions" },
        { name: "Privacy Notice", href: "/privacy-notice" },
        { name: "Cookies Policy", href: "/cookies-policy" },
        { name: "Ofcom Speed Commitment", href: "/ofcom-speed-commitment" },
        { name: "Accessibility Statement", href: "/accessibility-statement" },
      ],
    },
    {
      id: "company",
      title: "Our Company",
      links: [
        { name: "About Zoiko Broadband", href: "/about-us" },
        { name: "Our Sustainability Promise", href: "/our-sustainability" },
        { name: "Careers at Zoiko", href: "/careers" },
        { name: "Zoiko Group", href: "/zoiko-group" },
        { name: "Partners & Affiliations", href: "/partnership" },
      ],
    },
  ];

  return (
    <footer
      className="bg-[#10446C] dark:bg-gray-950 w-full border-t-2 border-[#0d3654] dark:border-gray-800 p-3"
      role="contentinfo"
    >
      <div className="footer-items w-[90%] mx-auto p-5 md:p-10">
        
        {/* Desktop View */}
        <div className="hidden lg:flex lg:flex-row justify-between">
          {footerSections.map((section) => (
            <div key={section.id}>
              <h2 className="text-2xl text-[#f5c241] font-bold my-3">
                {section.title}
              </h2>

              <ul className="text-[#CBD5E1] dark:text-gray-300 text-lg font-normal leading-10">
                {section.links.map((link, index) => (
                  <li key={index}>
                    <Link
                      href={link.href}
                      className="hover:text-[#f5c241] transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Mobile Accordion */}
        <FooterMenu sections={footerSections} />
      </div>

      {/* Bottom Copyright */}
      <div className="text-center p-2 border-t-2 border-[#0d3654] dark:border-gray-800 text-white w-[90%] mx-auto">
        <p className="font-semibold text-sm md:text-base">
          &copy; 2026 Zoiko Broadband | Zoiko Broadband is a trading name of
          Zoiko Telecom Ltd., registered in England & Wales | Company No.
          15021457 | VAT No 465 1110 23 |
        </p>

        <p className="font-semibold text-sm md:text-base">
          All rights reserved. Zoiko Telecom Ltd is Ofcom registered and adheres
          to the Broadband Speeds Code of Practice.
        </p>
      </div>
    </footer>
  );
}